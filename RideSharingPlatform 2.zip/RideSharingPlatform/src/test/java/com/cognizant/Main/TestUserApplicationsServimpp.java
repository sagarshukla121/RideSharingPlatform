package com.cognizant.Main;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.mockito.MockitoAnnotations;

import com.cognizant.Main.DTO.CompaniesDTO;
import com.cognizant.Main.DTO.UserApplicationsDTO;
import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.Entities.UserApplications;
import com.cognizant.Main.Repository.CompaniesRepository;
import com.cognizant.Main.Repository.DrivingLicensesRepository;
import com.cognizant.Main.Repository.UserApplicationRepository;
import com.cognizant.Main.UserApplicationsServimp.UserApplicationsServimpp;
import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.Role;
import com.cognizant.Main.utilities.UserApplicationsMapper;

import java.util.ArrayList;
import java.util.List;

public class TestUserApplicationsServimpp {
	
	@Mock
	private UserApplicationRepository userrepo;
	
	@Mock
	private CompaniesRepository cmrepo;
	
	@Mock
	private DrivingLicensesRepository dlrepo;
	
	@Mock
	private UserApplicationsMapper userApplicationsmapper;
	
	@InjectMocks
	private UserApplicationsServimpp userserv;
	
	@org.junit.jupiter.api.BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@org.junit.jupiter.api.AfterEach
	void tearDown() throws Exception {
		
	}
	
	@Test
	public void getuserresponsebyID_Positive() {
		
			
			Companies c=new Companies();
			
			c.setId(1);
			c.setCompanyName("Cognizant");
			c.setBuildingName("BuildingA");
			
			c.setSecurityInchargeName("Deepak");
			c.setSecurityHelpDeskNumber("1234567890");
			cmrepo.save(c);
			UserApplications u=new UserApplications();
			u.setUserId(100);
			u.setUsername("Deepak");
			u.setOfficialEmail("abc@email.com");
			u.setPhoneNumber("9841099807");
			u.setEmployeeId("1");
			u.setDesignation("Developer");
			u.setCompanyId(c);
			u.setAadharNumber("123456789012");
			u.setApplicationStatus(ApplicationStatus.NEW);
			u.setRole(Role.RIDER);
			userrepo.save(u);
			//int testuserId=100;
			
			Optional<UserApplications> Optionalofusers=Optional.of(u);
			when(userrepo.findById(u.getUserId())).thenReturn(Optionalofusers);
			//Optional<UserApplications> thenReturn = Optionalofusers;
			UserApplicationsDTO mockUserApplicationsDTO=new UserApplicationsDTO();
	        when(userApplicationsmapper.touserappdto(u)).thenReturn(mockUserApplicationsDTO);
			UserApplicationsDTO userresponse= userserv.getUserById(u.getUserId());
			assertNotNull(userresponse);
			
			
		
		
	}
	
	@Test
    public void getuserresponsebyID_Negative() {
    	UserApplications mockusers=new UserApplications();
    	
    	Optional<UserApplications> optionalOfusers = Optional.empty();
        when(userrepo.findById(2)).thenReturn(optionalOfusers);
        
        //ReservationsDTO mockReservationDTO = new ReservationsDTO();
        //when(reservationsMapper.toReservationDto(mockReservation)).thenReturn(mockReservationDTO);
        UserApplicationsDTO mockUserApplicationsDTO=new UserApplicationsDTO();
        when(userApplicationsmapper.touserappdto(mockusers)).thenReturn(mockUserApplicationsDTO);
        UserApplicationsDTO result = userserv.getUserById(2);
        assertNull(result);
    }
	
//	@Test
//	public void getuserresponsebyID_Negative() {
//		try {
//			int testuserId=0;
//			Optional<UserApplications> Optionalofusers=Optional.ofNullable(null);
//			when(userrepo.findById(testuserId)).thenReturn(Optionalofusers);
//		UserApplicationsDTO userresponse=userserv.getUserById(testuserId);
//			assertTrue(userresponse.getUserId()==0);
//			
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//		assertTrue(true);
//		}
//}
//	@Test
//	public void testupdate_Positive() {
//		try {
//Companies c=new Companies();
//			
//			c.setId(1);
//			c.setCompanyName("Cognizant");
//			c.setBuildingName("BuildingA");
//			
//			c.setSecurityInchargeName("Deepak");
//			c.setSecurityHelpDeskNumber("1234567890");
//			UserApplications u=new UserApplications();
//			u.setUserId(100);
//			u.setUsername("Deepak");
//			u.setOfficialEmail("abc@email.com");
//			u.setPhoneNumber("9841099807");
//			u.setEmployeeId("1");
//			u.setDesignation("Developer");
//			u.setCompanyId(c);
//			u.setAadharNumber("123456789012");
//			u.setApplicationStatus(ApplicationStatus.NEW);
//			u.setRole(Role.MOTORIST);
//			Optional<UserApplications> optionalOfusers=Optional.of(u);
//			when(userrepo.findById(100)).thenReturn(optionalOfusers);
//			UserApplicationsDTO usersupdated=new UserApplicationsDTO();
//			usersupdated.setUserId(100);
//			usersupdated.setUsername("Deepak");
//			usersupdated.setOfficialEmail("abc@email.com");
//			usersupdated.setPhoneNumber("9841099807");
//			usersupdated.setEmployeeId("1");
//			usersupdated.setDesignation("Developer");
//			usersupdated.setCompany(c);
//			usersupdated.setAadharNumber("123456789012");
//			usersupdated.setApplicationstatus(ApplicationStatus.APPROVED);
//			usersupdated.setRole(Role.MOTORIST);
//			when(userrepo.save(u)).thenReturn(usersupdated);
//			UserApplicationsDTO usersdto=new UserApplicationsDTO();
//			String actual=userserv.updateapprovereject(100,usersdto);
//			assertEquals("success",actual);
//		}
//		catch(Exception e) {
//			assertTrue(true);
//		}
//	}
//	
//    @Test
//	public void testupdate_positive() {
//		try {
//			UserApplications mockOfUserApplications=Mockito.mock(UserApplications.class);
//			Companies c=new Companies();
//			c.setId(1);
//			c.setCompanyName("Cognizant");
//			c.setBuildingName("BuildingA");
//			c.setSecurityHelpDeskNumber("1234567890");
//			c.setSecurityInchargeName("Deepak");
//			UserApplicationsDTO u=new UserApplicationsDTO();
//			u.setUserId(100);
//			u.setUsername("David");
//			u.setOfficialEmail("abc@email.com");
//			u.setEmployeeId("123");
//			u.setPhoneNumber("9841099807");
//			u.setDesignation("Developer");
//			u.setCompany(c);
//		    u.setAadharNumber("123456789012");
//		    u.setApplicationstatus(ApplicationStatus.APPROVED);
//		    u.setRole(Role.MOTORIST);
//		    Mockito.when(userrepo.findById(100)).thenReturn(Optional.of(mockOfUserApplications));
//		    
//		   Mockito.when(userrepo.save(Mockito.any(UserApplications.class))).thenReturn(mockOfUserApplications);
//		    String res= userserv.updateapprovereject(100, u);
//		    assertEquals("fail",res);
//		    
//		    
//			
//		}
//		catch(Exception e) {
//			e.printStackTrace();
//			assertTrue(false);
//		}
//	}
	@Test
	public void fetchAllCompaniesDetails_Positive() {
		List<Companies> mockCompaniesIterable = new ArrayList<Companies>();
		Companies company1=new Companies();
		company1.setId(5);
		company1.setCompanyName("CognizantB");
		company1.setBuildingName("BuildingA");
		company1.setSecurityHelpDeskNumber("9841099807");
		company1.setSecurityInchargeName("Kumar");
		
		Companies company2=new Companies();
		company2.setId(6);
		company2.setCompanyName("CognizantC");
		company2.setBuildingName("BuildingC");
		company2.setSecurityHelpDeskNumber("9834567890");
		company2.setSecurityInchargeName("Perumal");
		
		mockCompaniesIterable.add(company1);
		mockCompaniesIterable.add(company2);
		Mockito.when(cmrepo.findAll()).thenReturn(mockCompaniesIterable);
		List<CompaniesDTO> list=userserv.getCompaniesDetails();
		assertEquals(2,list.size());
		
		
		
	}
	
	@Test
	public void fetchAllCompaniesDetails_Negative() {
		List<Companies> mockCompaniesIterable=new ArrayList<Companies>();
		Mockito.when(cmrepo.findAll()).thenReturn(mockCompaniesIterable);
		List<CompaniesDTO> list=userserv.getCompaniesDetails();
		assertEquals(0,list.size());
	}
	

}
