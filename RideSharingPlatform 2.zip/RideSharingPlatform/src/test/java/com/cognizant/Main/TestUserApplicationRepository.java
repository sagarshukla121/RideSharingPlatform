package com.cognizant.Main;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.Main.Entities.Companies;
import com.cognizant.Main.Entities.UserApplications;
import com.cognizant.Main.Repository.CompaniesRepository;
import com.cognizant.Main.Repository.UserApplicationRepository;
import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.Role;

//import com.cognizant.Main.Repository.UserApplicationRepository;
 

@DataJpaTest
@ContextConfiguration(classes = RideSharingPlatformApplication.class)
class TestUserApplicationRepository {

	@Autowired
	private UserApplicationRepository user;
	
	@Autowired
	private CompaniesRepository company;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void testFindAllPositive() {
		Companies c=new Companies();
		c.setId(1);
	c.setCompanyName("Cognizant");
		c.setBuildingName("BuildingA");
		
	c.setSecurityInchargeName("Deepak");
		c.setSecurityHelpDeskNumber("1234567890");
		
		UserApplications users=new UserApplications();
		users.setUserId(2);
		users.setUsername("John");
		users.setOfficialEmail("abc@gmail.com");
		users.setPhoneNumber("1234567890");
		users.setCompanyId(c);
		users.setDesignation("Developer");
		users.setRole(Role.MOTORIST);
		users.setEmployeeId("123");
		users.setAadharNumber("123456789012");
		users.setApplicationStatus(ApplicationStatus.NEW);
		entityManager.persist(c);
	entityManager.persist(users);
	Iterable<UserApplications> it= user.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
	@Test
	public void testFindByIdPositive() {
		Companies c=new Companies();
		c.setId(1);
		c.setCompanyName("Cognizant");
		c.setBuildingName("BuildingA");
		
		c.setSecurityInchargeName("Deepak");
		c.setSecurityHelpDeskNumber("1234567890");
		
		UserApplications users=new UserApplications();
		users.setUserId(2);
		users.setUsername("John");
		users.setOfficialEmail("abc@gmail.com");
		users.setPhoneNumber("1234567890");
		users.setCompanyId(c);
		users.setDesignation("Developer");
		users.setRole(Role.MOTORIST);
		users.setEmployeeId("123");
		users.setAadharNumber("123456789012");
		users.setApplicationStatus(ApplicationStatus.NEW);
		
		entityManager.persist(users);
		Optional<UserApplications> userapp= user.findById(2);
		assertTrue(userapp.isPresent());
	}
	
	 @Test
	  public void testFindAllNegative() {
		Iterable<UserApplications> it=user.findAll();
		assertFalse(it.iterator().hasNext());
	}
	 
	 @Test
		public void testDeletePositive() {
			Companies c=new Companies();
			c.setId(1);
			c.setCompanyName("Cognizant");
			c.setBuildingName("BuildingA");
			
			c.setSecurityInchargeName("Deepak");
			c.setSecurityHelpDeskNumber("1234567890");
			entityManager.persist(c);
		//company.delete(c);
		UserApplications users=new UserApplications();
		users.setUserId(2);
		users.setUsername("John");
		users.setOfficialEmail("abc@gmail.com");
		users.setPhoneNumber("1234567890");
		users.setCompanyId(c);
		users.setDesignation("Developer");
		users.setRole(Role.MOTORIST);
		users.setEmployeeId("123");
		users.setAadharNumber("123456789012");
		users.setApplicationStatus(ApplicationStatus.NEW);
		user.delete(users);
		Optional<UserApplications> userapp=user.findById(2);
		assertFalse(userapp.isPresent());
		
		}
	 
	    @Test
		public void testFindByIdNegative() {
			Optional<UserApplications> userapp=user.findById(2);
			assertFalse(userapp.isPresent());
		}
	    
	    @Test
	    public void testSavePositive() {
	    	Companies c=new Companies();
	    		c.setId(1);
	    		c.setCompanyName("Cognizant");
	    	c.setBuildingName("BuildingA");
	    	
	    		c.setSecurityInchargeName("Deepak");
	    		c.setSecurityHelpDeskNumber("1234567890");
	    	
	    	company.save(c);
	    		UserApplications users=new UserApplications();
	    		users.setUserId(2);
	    		users.setUsername("John");
	    		users.setOfficialEmail("abc@gmail.com");
	    		users.setPhoneNumber("1234567890");
	    		users.setCompanyId(c);
	    		users.setDesignation("Developer");
	    		users.setRole(Role.MOTORIST);
	    		users.setEmployeeId("123");
	    		users.setAadharNumber("123456789012");
	    		users.setApplicationStatus(ApplicationStatus.NEW);
	    		user.save(users);
	    	Optional<UserApplications> userapp=user.findById(2);
	    	assertTrue(userapp.isPresent());
	    	}

}
