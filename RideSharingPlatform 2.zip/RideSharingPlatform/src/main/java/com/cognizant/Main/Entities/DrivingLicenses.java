package com.cognizant.Main.Entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDate;



@Entity
@Table(name="Driving_Licenses")
public class DrivingLicenses {
	
	@jakarta.persistence.Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Id")
	private int Id;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	//@PrimaryKeyJoinColumn(name="User_Id")
	private UserApplications user;
	
	//@Pattern(regexp = "^[A-Z]{3}\\d{4}[A-Z]{3}$", message = "Invalid driving license number")
	@Column(name="LicenseNo")
	private String LicenseNo;
	
	//@Future(message = "Expiration date must not be a past date")
	@Column(name="ExpirationDate")
	private LocalDate ExpirationDate;
	
	@Column(name="RTA")
	private String RTA;
	
	@Column(name="AllowedVehicles")
	private String AllowedVehicles;
	
	public String getLicenseNo() {
		return LicenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		LicenseNo = licenseNo;
	}
	public LocalDate getExpirationDate() {
		return ExpirationDate;
	}
	public void setExpirationDate(LocalDate expirationDate) {
		ExpirationDate = expirationDate;
	}
	public String getRTA() {
		return RTA;
	}
	public void setRTA(String rTA) {
		RTA = rTA;
	}
	public String getAllowedVehicles() {
		return AllowedVehicles;
	}
	public void setAllowedVehicles(String allowedVehicles) {
		AllowedVehicles = allowedVehicles;
	}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		this.Id = id;
	}
	
	
	public void setUser(UserApplications user) {
		this.user = user;
	}
	public UserApplications getUser() {return user;}
	
	
	
	

}
