package com.cognizant.Main.Entities;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.boot.autoconfigure.web.WebProperties.Resources.Chain.Strategy;

import com.cognizant.Main.utilities.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;


@Entity
@Table(name="User_Applications")
public class UserApplications {
	
	@Id
	@Column(name="User_Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int UserId;
	
	
	@ManyToOne
	@JoinColumn(name="CompanyId")
	private Companies company;
	
	@Column(name="Username")
	private String Username;
	
	@Column(name="OfficialEmail")
	private String OfficialEmail;
	
	@Pattern(regexp = "\\d{10}", message = "Phone number must be 10 digits")
	@Column(name="PhoneNumber")
	private String PhoneNumber;
	
	@Column(name="Designation")
	private String Designation;
	
	@Column(name="Role")
	@Enumerated(EnumType.STRING)
	private Role Role;
	
	@Column(name="EmployeeId")
	private String EmployeeId;
	
	@Pattern(regexp = "\\d{12}", message = "Aadhar number must be 12 digits")
	@Column(name="AadharNumber")
	private String AadharNumber;
	
	@Column(name="ApplicationStatus")
	@Enumerated(EnumType.STRING)
	private ApplicationStatus applicationstatus;
	
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		this.Username = username;
	}
	public String getOfficialEmail() {
		return OfficialEmail;
	}
	public void setOfficialEmail(String officialEmail) {
		this.OfficialEmail = officialEmail;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.PhoneNumber = phoneNumber;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		this.Designation = designation;
	}
	public Role getRole() {
		return Role;
	}
	public void setRole(Role role) {
		this.Role = role;
	}
	public String getEmployeeId() {
		return EmployeeId;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		this.UserId = userId;
	}
	public void setEmployeeId(String employeeId) {
		this.EmployeeId = employeeId;
	}
	public String getAadharNumber() {
		return AadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.AadharNumber = aadharNumber;
	}
	public ApplicationStatus getApplicationStatus() {
		return applicationstatus;
	}
	public void setApplicationStatus(ApplicationStatus applicationStatus) {
		this.applicationstatus = applicationStatus;
	}
	
	public void setCompanyId(Companies company) {
		this.company=company;
	}
	
	public Companies getCompanyId() {
		return company;
	}
	
	public Companies getComapany() { return company;}
	
	@PrePersist
	public void beforePersist() {
		System.out.println("UserId:"+UserId);
	}
	
	

}
