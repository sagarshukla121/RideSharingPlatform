package com.cognizant.Main.utilities;

import org.springframework.stereotype.Component;

import com.cognizant.Main.DTO.UserApplicationsDTO;
import com.cognizant.Main.Entities.UserApplications;

@Component
public class UserApplicationsMapper {
	
	public UserApplicationsDTO touserappdto(UserApplications users) {
		UserApplicationsDTO usersappdto=new UserApplicationsDTO();
		usersappdto.setUserId(users.getUserId());
		usersappdto.setUsername(users.getUsername());
		usersappdto.setOfficialEmail(users.getOfficialEmail());
		usersappdto.setEmployeeId(users.getPhoneNumber());
		usersappdto.setCompany(users.getCompanyId());
		usersappdto.setAadharNumber(users.getAadharNumber());
		usersappdto.setApplicationstatus(users.getApplicationStatus());
		usersappdto.setDesignation(users.getDesignation());
		usersappdto.setPhoneNumber(users.getPhoneNumber());
		usersappdto.setRole(users.getRole());
		
		return usersappdto;
	}

}
