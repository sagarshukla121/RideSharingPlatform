package com.cognizant.Main.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Pattern;


public class CompaniesDTO {
	
	@jakarta.persistence.Id
	@Column(name="id")
	private int Id;
	
	@Column(name="companyName")
	private String CompanyName;
	
	@Column(name="buildingName")
	private String BuildingName;
	
	@Column(name="securityInchargeName")
	private String SecurityInchargeName;
	
	@Pattern(regexp = "\\d{10}", message = "Security help desk number must be 10 digits")
	@Column(name="securityHelpDeskNumber")
	private String SecurityHelpDeskNumber;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		this.Id = id;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getBuildingName() {
		return BuildingName;
	}

	public void setBuildingName(String buildingName) {
		BuildingName = buildingName;
	}

	public String getSecurityInchargeName() {
		return SecurityInchargeName;
	}

	public void setSecurityInchargeName(String securityInchargeName) {
		SecurityInchargeName = securityInchargeName;
	}

	public String getSecurityHelpDeskNumber() {
		return SecurityHelpDeskNumber;
	}

	public void setSecurityHelpDeskNumber(String securityHelpDeskNumber) {
		SecurityHelpDeskNumber = securityHelpDeskNumber;
	}

}
