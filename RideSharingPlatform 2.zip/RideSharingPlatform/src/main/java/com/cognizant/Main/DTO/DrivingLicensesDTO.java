package com.cognizant.Main.DTO;

import java.time.LocalDate;

import com.cognizant.Main.Entities.UserApplications;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Pattern;


public class DrivingLicensesDTO {
	@jakarta.persistence.Id
	@Column(name="Id")
	private int Id;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn(name="UserId")
	private UserApplications user;
	
	@Pattern(regexp = "^[A-Z]{3}\\d{4}[A-Z]{3}$", message = "Invalid driving license number")
	@Column(name="LicenseNo")
	private String LicenseNo;
	
	@Future(message = "Expiration date must not be a past date")
	@Column(name="ExpirationDate")
	private LocalDate ExpirationDate;
	
	@Column(name="RTA")
	private String RTA;
	
	@Column(name="AllowedVehicles")
	private String AllowedVehicles;
	
	public String getLicenseNo() {
		return LicenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		LicenseNo = licenseNo;
	}
	public LocalDate getExpirationDate() {
		return ExpirationDate;
	}
	public void setExpirationDate(LocalDate expirationDate) {
		ExpirationDate = expirationDate;
	}
	public String getRTA() {
		return RTA;
	}
	public void setRTA(String rTA) {
		RTA = rTA;
	}
	public String getAllowedVehicles() {
		return AllowedVehicles;
	}
	public void setAllowedVehicles(String allowedVehicles) {
		AllowedVehicles = allowedVehicles;
	}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	
	public void setUser(UserApplications user) {
		this.user = user;
	}
	public UserApplications getUser() {return user;}

}
