package com.cognizant.Main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.Main.Entities.DrivingLicenses;
//import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface DrivingLicensesRepository extends JpaRepository<DrivingLicenses,Integer>{

}
