package com.cognizant.Main.Controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Main.DTO.UserApplicationsDTO;
import com.cognizant.Main.DTO.userdrivingDTO;
import com.cognizant.Main.Entities.DrivingLicenses;
import com.cognizant.Main.Service.UserApplicationsServ;
import com.cognizant.Main.utilities.InvalidMotoristRegistration;
import com.cognizant.Main.DTO.CompaniesDTO;
import java.util.List;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("api")
public class UserApplicationsCon {
	 @Autowired
	 UserApplicationsServ users;
	 
	@PostMapping("applications/new")
	public ResponseEntity<?> adduser(@Valid @RequestBody userdrivingDTO userdto) throws InvalidMotoristRegistration{
		
		String result=users.adduser(userdto);
		 if(result.equals("success")) {
			 return new ResponseEntity<>("new user added successfully"+userdto.getUserId(),HttpStatus.CREATED);
			 
		 }
		 else {
			 return new ResponseEntity<>("new user already exists"+userdto.getUserId(),HttpStatus.BAD_REQUEST);
		 }
	 }
	
	@PutMapping("/applications/{approvereject}")
	public ResponseEntity<?> updateapprovereject(@PathVariable ("approvereject") int UserId , @RequestBody UserApplicationsDTO usersdto) {
		//TODO: process PUT request
		System.out.println("Hello World");
		String result= users.updateapprovereject(UserId,usersdto);
		if(result.equals("success")) {
			return new ResponseEntity<>("updated application status"+usersdto.getUserId(),HttpStatus.CREATED);
		}
		else {
			return new ResponseEntity<>("failed to update"+usersdto.getUserId(),HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@GetMapping("/applications/{userid}")
	public ResponseEntity<?> getById(@PathVariable("userid") int userid){
		UserApplicationsDTO result= users.getUserById(userid);
		if(result.getUserId()!=0) {
			return new ResponseEntity<>(result,HttpStatus.OK);
		}
		else {
			String message="User not found";
			return new ResponseEntity<>(message,HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("applications/companies")
	public ResponseEntity<List<CompaniesDTO>> getDetails(){
		List<CompaniesDTO> allCompanies =null;
		try {
			allCompanies = users.getCompaniesDetails();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<>(allCompanies,HttpStatus.OK);
	}
	
	@GetMapping("applications/")
	public ResponseEntity<List<UserApplicationsDTO>> getPendingDetails(){
		System.out.println("IN CONTROLLER");
		List<UserApplicationsDTO> pendingdetails = null;
		try {
			pendingdetails = users.getpending();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<>(pendingdetails,HttpStatus.OK);
	}
	
	
}
