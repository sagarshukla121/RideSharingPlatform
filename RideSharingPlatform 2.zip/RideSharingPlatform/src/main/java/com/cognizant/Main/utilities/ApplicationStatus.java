package com.cognizant.Main.utilities;

public enum ApplicationStatus {
		NEW("NEW"),
		APPROVED("APPROVED"),
		REJECTED("rejected");
	
	String val;
	private ApplicationStatus (String val) {
		this.val=val;
	}
	
	public String getVal() {
		return val;
	}
}
