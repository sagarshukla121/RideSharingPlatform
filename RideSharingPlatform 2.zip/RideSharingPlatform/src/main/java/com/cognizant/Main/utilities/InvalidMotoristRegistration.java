package com.cognizant.Main.utilities;

public class InvalidMotoristRegistration extends Exception{
	public InvalidMotoristRegistration() {
		super("Invalid Driving License Details");
	
	}
}
