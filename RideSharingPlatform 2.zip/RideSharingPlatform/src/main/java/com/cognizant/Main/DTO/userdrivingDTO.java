package com.cognizant.Main.DTO;

import java.time.LocalDate;

import com.cognizant.Main.utilities.ApplicationStatus;
import com.cognizant.Main.utilities.Role;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Pattern;

public class userdrivingDTO {
	

	private int userId;
	
	private String userNme;
	
	private String officialEmail;
	
	@Pattern(regexp = "^9\\d{9}$", message = "Phone number must be 10 digits and should start with 9")
	private String phoneNumber;
	
	private String designation;
	
	@Enumerated(EnumType.STRING)
	private Role Role;
	
	private String employeeId;
	
	@Pattern(regexp = "\\d{12}", message = "Aadhar number must be 12 digits")
	private String aadharNumber;
	
	@Enumerated(EnumType.STRING)
	private ApplicationStatus applicationStatus;
	
	private int Id;
	//@Pattern(regexp = "^[A-Z]{3}\\d{4}[A-Z]{3}$", message = "Invalid driving license number")
	private String licenseNo;
	
	@Future(message = "Expiration date must not be a past date")
	private LocalDate expirationDate;
	
	private String rta;
	
	private String allowedVehicles;
	
	
	private String userApplicationsuserid;
	private String drivingLicensesuserid;
	
	private int companyId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	

	public String getUserNme() {
		return userNme;
	}

	public void setUserNme(String userNme) {
		this.userNme = userNme;
	}

	public String getOfficialEmail() {
		return officialEmail;
	}

	public void setOfficialEmail(String officialEmail) {
		this.officialEmail = officialEmail;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Role getRole() {
		return Role;
	}

	public void setRole(Role role) {
		Role = role;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}



	public ApplicationStatus getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(ApplicationStatus applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public LocalDate getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(LocalDate expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getRta() {
		return rta;
	}

	public void setRta(String rta) {
		this.rta = rta;
	}

	public String getAllowedVehicles() {
		return allowedVehicles;
	}

	public void setAllowedVehicles(String allowedVehicles) {
		this.allowedVehicles = allowedVehicles;
	}

	public String getUserApplicationsuserid() {
		return userApplicationsuserid;
	}

	public void setUserApplicationsuserid(String userApplicationsuserid) {
		this.userApplicationsuserid = userApplicationsuserid;
	}

	public String getDrivingLicensesuserid() {
		return drivingLicensesuserid;
	}

	public void setDrivingLicensesuserid(String drivingLicensesuserid) {
		this.drivingLicensesuserid = drivingLicensesuserid;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	
	
	

}
